#include <stdio.h>

void sortArrayIncreasing(int original[], int size);
void sortArrayDecreasing(int original[], int size);

int main(int argc, char* argv[])
{
   
    FILE *fp;

  fp = fopen(argv[1],"r");

    if(fp == NULL){
	    printf("error\n");
	    return 0;
    }
   int count;

  if( fscanf(fp,"%d\n", &count) == 1){

  if(count == 0){
    printf("\n");
    return 0;
  }

  }else{
	  printf("\n");
     return 0;
  }

   int a[count];


   for(int i =0; i < count; i ++){
       fscanf(fp, "%d \t", &a[i]);
      

   }


   int evenCount = 0;
   int oddCount = 0;

   for(int i=0; i < count; i ++){
       if(a[i] % 2 == 0){
          evenCount++;
       }else{
          oddCount++;
       }
   }
   

   int evenArray[evenCount+1];
   int oddArray[oddCount+1];


   int ec = 0;
   int oc = 0;
   for(int i=0; i < count; i ++){
       if(a[i] % 2 == 0){

          evenArray[ec]=a[i];
          ec++;
       }
       
   }

    for(int i=0; i < count; i ++){
       if(a[i] % 2 != 0){
          oddArray[oc]=a[i];
          oc++;
       }
   
    }

   sortArrayIncreasing(evenArray, evenCount);
   sortArrayDecreasing(oddArray, oddCount);



   for(int i = 0; i < ec; i ++){
       a[i] = evenArray[i];
   }
   
  for(int i = 0; i < oc; i ++){
       a[ec + i] = oddArray[i];
   }

  for(int i = 0; i < count; i ++){
      printf("%d\t",a[i]);
   }
   printf("\n");
   

fclose(fp);
return 0;

}


void sortArrayIncreasing(int original[], int size){
       if(size == 0)
         return;

 for(int i=0;i<size;i++){
      for(int j=i+1;j<size;j++){
         if(original[i]>original[j]){
            int temp=original[i];
            original[i]=original[j];
            original[j]=temp;
         }
      }
   }


}

void sortArrayDecreasing(int original[], int size){
    if(size == 0)
    return;

for(int i=0;i<size;i++){
      for(int j=i+1;j<size;j++){
         if(original[i]<original[j]){
            int temp=original[i];
            original[i]=original[j];
            original[j]=temp;
         }
      }
   }
}
