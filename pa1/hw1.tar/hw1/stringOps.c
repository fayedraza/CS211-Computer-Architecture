#include <stdio.h>

int main(int argc, char* argv[])
{

    if(argv == NULL || argv[0] == '\0' || argv[1] == '\0' ){
	printf("\n");
    return 0;
    }


for(int j = 1; argv[j] != '\0'; j++){  
char *test = argv[j];
for(int i  = 0; test[i] != '\0'; i++ ){
if(test[i] == 'a' || test[i] == 'e' || test[i] == 'i' || test[i] == 'o' || test[i] == 'u' || test[i] == 'A' || test[i] == 'E' || test[i] == 'I' || test[i] == 'O' || test[i] == 'U' ){
       
	printf("%c", test[i]);
}
}
}


printf("\n");


return 0;
}

