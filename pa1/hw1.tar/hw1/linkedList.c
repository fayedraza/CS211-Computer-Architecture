#include <stdio.h>
#include <stdlib.h>

struct linkedlist{
        struct linkedlist * next;
        int data;
      
};

struct linkedlist * head = NULL;


struct linkedlist * addNode(struct linkedlist * prev, struct linkedlist * curr, int value, int b){

  if(b){
    return curr;
  }

if(curr  == NULL && prev == NULL){
    head  = malloc(sizeof(struct node *) * 3 );
    head -> data = value;
    head ->  next = curr;
    return head;
}else if (curr ==  NULL){
    prev -> next  = malloc(sizeof(struct node *) * 3 );
    prev -> next -> data = value;
    prev -> next ->  next = curr;
    return prev;
}else if (prev == NULL && curr -> data >= value){
    prev = malloc(sizeof(struct node *) * 3 );
    prev -> data = value;
    prev -> next = addNode(prev, curr, value, 1);
    return prev;
}else if (curr -> data >= value){
    prev -> next  = malloc(sizeof(struct node *) * 3 );
    prev -> next -> data = value;
    prev -> next ->  next = addNode(prev, curr, value, 1);
    return prev -> next;
}else if (curr -> data < value &&  curr -> next == NULL){
    curr -> next  = malloc(sizeof(struct node *) * 3 );
    curr -> next -> data = value;
    curr -> next ->  next = NULL;
    return curr;
}else{
  curr ->  next = addNode(curr, curr -> next, value, 0);
  return curr;
}


 

}

struct linkedlist * deleteNode( struct linkedlist * curr, int target){

if(curr  == NULL){
  return NULL;
}else if (curr -> data == target){
    struct linkedlist * temp = NULL;
    temp  = curr -> next;
    free(curr);
    return temp;
}else{
  curr ->  next = deleteNode(curr -> next, target);
  return curr;
}


 

}

void printList(struct linkedlist * prev, struct linkedlist * curr){
if(curr == NULL){
prev = NULL;

}else{

    if(prev == NULL){

       printf("%d\t",curr -> data);
       printList(curr, curr -> next);

    }else{
      if(prev ->  data !=  curr -> data){
       printf("%d\t",curr -> data);
      }
       printList(curr, curr -> next);
    }

  
    
     
}



}






int checkIfItExists(struct linkedlist * head, int target){
   if(head  == NULL)
   return 0;

   struct linkedlist * ptr = head;

   while(ptr != NULL){
     if(ptr -> data == target ){
       return 1;
     }

     ptr=ptr -> next;
   }
  

   return 0;
}




int main(int argc, char* argv[]) {

FILE *fp = fopen(argv[1],"r");

 char InsertOrDelete;
  int value;
  
  


if(fp == NULL){
printf("error\n");
}else{


int count = 0;
int s = 1;

while(fscanf(fp,"%c\t%d\n", &InsertOrDelete, &value) == 2) {

      s=0;	

if(InsertOrDelete == 'i'){  
   
  count++;
 head = addNode(NULL, head, value, 0);

}else if(InsertOrDelete == 'd'){
     

     if(head == NULL || !checkIfItExists(head,value)){

     }else{
       count--;
       head = deleteNode(head,value);
     }
}


}

if(s){
printf("%d\n",0);
printf("\n");
	return 0;
}

printf("%d\n", count);

if(count != 0){
printList(NULL, head);
printf("\n");
}else{
	printf("\n");
}


 struct linkedlist * temp = head;

    while(temp != NULL){
      struct linkedlist * curr = temp;
      temp =  temp ->  next;
      free(curr);
    }

  

fclose(fp);

}

  return 0;
}




/*void freeList(struct linkedlist * head){
    struct linkedlist * temp = head;

    while(temp ->  next == NULL){
      struct linkedlist * curr = temp;
      temp =  temp ->  next;
      free(curr);
    }

    if(temp){
      free(temp);
    }
}*/
