#include <stdio.h>
#include <stdlib.h>

struct linkedlist{
        struct linkedlist * next;
        int data;
      
};

struct linkedlist * hashTable[10000];

int getKey(int num){
    int val =  num  % 10000;  
    if(val  < 0 ){
    val =  10000 + val; 
    }
    return val;
}


int search(int key, int target){
    if(hashTable[key] == NULL){

       return 0;
    }else{
        struct linkedlist * ptr = hashTable[key];

        while(ptr !=  NULL){
            if(ptr -> data == target ){
                return 1;
            }

            ptr=ptr -> next;
        }
    }

    return 0;

}

int insert(int key, int value){
      if(hashTable[key] == NULL){
           struct linkedlist * ptr = hashTable[key];
           struct linkedlist * node;
           node = malloc(sizeof(struct linkedlist *)*2);
           node -> data = value;
           node -> next = ptr;
           hashTable[key] = node;


          return 0;
      }else{
            if(search(getKey(value), value)){
               return 1;
              }else{
                struct linkedlist * ptr = hashTable[key];
                struct linkedlist * node;
                node = malloc(sizeof(struct linkedlist *)*2);
                 node -> data = value;
                 node -> next = ptr;
               hashTable[key] = node;
               return 1;
              }
      }

return 0;   

}



int main(int argc, char* argv[]){

     FILE *fp = fopen(argv[1],"r");

 char InsertOrDelete;
   int value;



if(fp == NULL){
	printf("error\n");
return 0;
}

for(int i=0; i <  10000; i++){
    hashTable[i]=NULL;
}

int collisions = 0;
int sucessfulSearches = 0;
int s=1;
while(fscanf(fp,"%c\t%d\n", &InsertOrDelete, &value) == 2) {
s=0;
if(InsertOrDelete == 'i'){
     if(insert( getKey(value), value)){
         collisions++;
     }
}else if(InsertOrDelete == 's'){
   if(search(getKey(value), value)){
     sucessfulSearches++;
   }
}


}
if(s){
	printf("%d\n",0);
	printf("%d\n",0);
	return 0;
}
fclose(fp);
printf("%d\n", collisions);
printf("%d\n", sucessfulSearches);

}
